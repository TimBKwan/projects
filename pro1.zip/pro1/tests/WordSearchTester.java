import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.util.*;

/**
 * Code to test <tt>WordSearch3D</tt>.
 */
public class WordSearchTester {
    private WordSearch3D _wordSearch;

    @Test
    /**
     * Verifies that make can generate a very simple puzzle that is effectively 1d.
     */
    public void testMake1D () {
        final String[] words = new String[] { "java" };
        // Solution is either java or avaj
        final char[][][] grid = _wordSearch.make(words, 1, 1, 4);
        final char[] row = grid[0][0];
        System.out.println(row[0]);
        System.out.println(row[1]);
        System.out.println(row[2]);
        System.out.println(row[3]);
        assertTrue((row[0] == 'j' && row[1] == 'a' && row[2] == 'v' && row[3] == 'a') ||
                (row[3] == 'j' && row[2] == 'a' && row[1] == 'v' && row[0] == 'a'));
    }

    @Test
    /**
     * Verifies that make can generate a puzzle that is effectively 2d
     */
    public void testMake2D () {
        final String[] words = new String[] { "hello", "world" };
        final char[][][] grid = _wordSearch.make(words, 1, 5, 3 );
        assertNotNull(grid);
        assertNotNull(_wordSearch.search(grid, "hello"));
        assertNotNull(_wordSearch.search(grid, "world"));
    }

    @Test
    /**
     * Verifies that make can generate a puzzle that is effectively 3d
     */
    public void testMake3D () {
        final String[] words = new String[] { "he", "love", "you" };
        final char[][][] grid = _wordSearch.make(words, 3, 4, 3 );
        assertNotNull(grid);
        assertNotNull(_wordSearch.search(grid, "he"));
        assertNotNull(_wordSearch.search(grid, "love"));
        assertNotNull(_wordSearch.search(grid, "you"));
    }

    @Test
    /**
     * Verifies that make returns null when it's impossible to construct a puzzle.
     */
    public void testMakeImpossible () {
        final String[] words = new String[] { "cat", "dog", "tg", "td"};
        final char[][][] grid = _wordSearch.make(words, 2, 3, 1);
        assertNull(grid);
    }

    @Test
    /**
     * Verify that make should return null when its impossible to fit a word in the grid
     */
    public void testMakeImpossibleFit () {
        final String[] words = new String[] { "hello" };
        final char[][][] grid = _wordSearch.make(words, 4, 4, 4);
        assertNull(grid);
    }

    @Test
    /**
     * Verify that make should return null when its grid size is 0
     */
    public void testMakeImpossibleGridSize () {
        final String[] words = new String[] { "hello" };
        final char[][][] grid = _wordSearch.make(words, 0, 3, 2);
        assertNull(grid);
    }

    @Test
    /**
     * verifies that passing an empty list of strings returns null
     */
    public void testEmptyStrings () {
        final String[] words = new String[0];
        final char[][][] grid = _wordSearch.make(words, 2, 3, 1);
        assertNotNull(grid);
    }

    @Test
    /**
     *  Verifies that search works correctly in a tiny grid that is effectively 2D.
     */
    public void testSearchSimple () {
        // Note: this grid is 1x2x2 in size
        final char[][][] grid = new char[][][] { { { 'a', 'b', 'c' },
                { 'd', 'f', 'e' } } };
        final int[][] location = _wordSearch.search(grid, "be");

        assertNotNull(location);
        assertEquals(location[0][0], 0);
        assertEquals(location[0][1], 0);
        assertEquals(location[0][2], 1);
        assertEquals(location[1][0], 0);
        assertEquals(location[1][1], 1);
        assertEquals(location[1][2], 2);
    }

    @Test
    /**
     * Verifies that make can generate a grid when it's *necessary* for words to share
     * some common letter locations.
     */
    public void testMakeWithIntersection () {
        final String[] words = new String[] { "amc", "dmf", "gmi", "jml", "nmo", "pmr", "smu", "vmx", "yma", "zmq" };
        final char[][][] grid = _wordSearch.make(words, 3, 3, 3);
        assertNotNull(grid);
    }

    @Test
    /**
     * Verifies that make can generate a grid when it's *necessary* for words to share
     * some common letter locations. simpler version
     */
    public void testMakeWithIntersectionSimpler () {
        final String[] words = new String[] { "amc", "dmf", "gmi", "jml", "nmo", "pmr", "smu", "vmx"};
        final char[][][] grid = _wordSearch.make(words, 3, 3, 3);
        assertNotNull(grid);
    }

    @Test
    /**
     * Verifies that make returns a grid of the appropriate size.
     */
    public void testMakeGridSize () {
        final String[] words = new String[] { "at", "it", "ix", "ax" };
        final char[][][] grid = _wordSearch.make(words, 17, 11, 13);
        assertEquals(grid.length, 17);
        for (int x = 0; x < 2; x++) {
            assertEquals(grid[x].length, 11);
            for (int y = 0; y < 2; y++) {
                assertEquals(grid[x][y].length, 13);
            }
        }
    }

    @Test
    /**
     * Verifies that search returns a grid of size 0 if word is empty string
     */
    public void testSearchEmptyString () {
        final char[][][] grid = new char[][][] { { { 'x', 'y', 'z' },
                { 'h', 'i', 'j' } } };
        final int[][] location = _wordSearch.search(grid, "");
        assertNotNull(location);
        assertEquals(location.length, 0);
    }

    @Test
    /**
     * Verifies that search returns null if word is null
     */

    public void testSearchNullWord () {
        final char[][][] grid = new char[][][] { { { 'f', 'y', 'z', 's'},
                {'f', 'g', 't', 'a'}, {'x', 's', 'p', 'i' } }};
        final int[][] location = _wordSearch.search(grid, null);
        assertNull(location);
    }

    @Test
    /**
     * Verifies that search returns null if word is not in grid
     */
    public void testSearchWordNotInGrid () {
        final char[][][] grid = new char[][][] { { { 'f', 'y', 'z', 's'},
                {'f', 'g', 't', 'a'}, {'x', 's', 'p', 'i' } }};
        final int[][] location = _wordSearch.search(grid, "cat");
        assertNull(location);

    }

    @Test
    /**
     * Verifies that search returns the word in a 3D grid (4x4x4) in the right location
     * This first one has the word in 3d- that is, all 3 coordinates (i,j,k) change in the diff
     * fish (0,0,0) (1,1,1) (2,2,2) (3,3,3)
     */

    public void testSearchComplex1 () {
        final char[][][] grid = new char[][][] {
                {{ 'f', 'b', 'x', 'x'}, {'s', 'u', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'x', 't', 'x', 's'} }, //[0]
                {{ 'i', 'o', 'x', 'x'}, {'x', 'i', 'x', 'x'}, {'x', 'x', 'e', 'x'}, {'x', 's', 's', 'x'} }, //[1]
                {{ 'n', 'y', 'x', 'x'}, {'o', 'y', 'x', 'x'}, {'p', 'x', 's', 'x'}, {'e', 'e', 'x', 'x'} }, //[2]
                {{ 'e', 'x', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'l', 't', 'x', 'h'} }}; //[3]
        final int[][] location = _wordSearch.search(grid, "fish");
        assertNotNull(location);
        assertEquals(location[0][0], 0);
        assertEquals(location[0][1], 0);
        assertEquals(location[0][2], 0);
        assertEquals(location[1][0], 1);
        assertEquals(location[1][1], 1);
        assertEquals(location[1][2], 1);
        assertEquals(location[2][0], 2);
        assertEquals(location[2][1], 2);
        assertEquals(location[2][2], 2);
        assertEquals(location[3][0], 3);
        assertEquals(location[3][1], 3);
        assertEquals(location[3][2], 3);
    }

    @Test
    /**
     * Verifies that search returns null if word is too long
     * even if part of the word is in the grid
     */

    public void testSearchWordTooLong () {
        final char[][][] grid = new char[][][] { {
                { 'f', 'b', 'x', 'x'}, {'s', 'u', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'x', 't', 'x', 's'} }, {
                { 'i', 'o', 'x', 'x'}, {'x', 'i', 'x', 'x'}, {'x', 'x', 'e', 'x'}, {'x', 's', 's', 'x'} }, {
                { 'n', 'y', 'x', 'x'}, {'o', 'y', 'x', 'x'}, {'p', 'x', 's', 'x'}, {'e', 'e', 'x', 'x'} }, {
                { 'e', 'x', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'l', 't', 'x', 'h'} }};
        final int[][] location = _wordSearch.search(grid, "fines");
        assertNull(location);
    }

    @Test

    /**
     * Verifies that search returns word that is only in the z direction
     * nope (2,0,0) (2,1,0) (2,2,0) (2,3,0)
     */

    public void testSearchComplex2 () {
        final char[][][] grid = new char[][][] { {
                { 'f', 'b', 'x', 'x'}, {'s', 'u', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'x', 't', 'x', 's'} }, {
                { 'i', 'o', 'x', 'x'}, {'x', 'i', 'x', 'x'}, {'x', 'x', 'e', 'x'}, {'x', 's', 's', 'x'} }, {
                { 'n', 'y', 'x', 'x'}, {'o', 'y', 'x', 'x'}, {'p', 'x', 's', 'x'}, {'e', 'e', 'x', 'x'} }, {
                { 'e', 'x', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'l', 't', 'x', 'h'} }};
        final int[][] location = _wordSearch.search(grid, "nope");
        assertNotNull(location);
        assertEquals(location[0][0], 2);
        assertEquals(location[0][1], 0);
        assertEquals(location[0][2], 0);
        assertEquals(location[1][0], 2);
        assertEquals(location[1][1], 1);
        assertEquals(location[1][2], 0);
        assertEquals(location[2][0], 2);
        assertEquals(location[2][1], 2);
        assertEquals(location[2][2], 0);
        assertEquals(location[3][0], 2);
        assertEquals(location[3][1], 3);
        assertEquals(location[3][2], 0);
    }

    @Test
    /**
     * Verifies that word search can return the word in the correct location
     * sux (0,1,0) (0,1,1) (0,1,2)
     */

    public void testSearchComplex3 () {
        final char[][][] grid = new char[][][] { {
                { 'f', 'b', 'x', 'x'}, {'s', 'u', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'x', 't', 'x', 's'} }, {
                { 'i', 'o', 'x', 'x'}, {'x', 'i', 'x', 'x'}, {'x', 'x', 'e', 'x'}, {'x', 's', 's', 'x'} }, {
                { 'n', 'y', 'x', 'x'}, {'o', 'y', 'x', 'x'}, {'p', 'x', 's', 'x'}, {'e', 'e', 'x', 'x'} }, {
                { 'e', 'x', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'l', 't', 'x', 'h'} }};
        final int[][] location = _wordSearch.search(grid, "sux");
        assertNotNull(location);
        assertEquals(location[0][0], 0);
        assertEquals(location[0][1], 1);
        assertEquals(location[0][2], 0);
        assertEquals(location[1][0], 0);
        assertEquals(location[1][1], 1);
        assertEquals(location[1][2], 1);
        assertEquals(location[2][0], 0);
        assertEquals(location[2][1], 1);
        assertEquals(location[2][2], 2);
    }

    @Test
    /**
     * Verifies that word search can return the word in the correct location
     *fine (0,0,0) (1,0,0) (2,0,0) (3,0,0)
     */

    public void testSearchComplex4 () {
        final char[][][] grid = new char[][][] { {
                { 'f', 'b', 'x', 'x'}, {'s', 'u', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'x', 't', 'x', 's'} }, {
                { 'i', 'o', 'x', 'x'}, {'x', 'i', 'x', 'x'}, {'x', 'x', 'e', 'x'}, {'x', 's', 's', 'x'} }, {
                { 'n', 'y', 'x', 'x'}, {'o', 'y', 'x', 'x'}, {'p', 'x', 's', 'x'}, {'e', 'e', 'x', 'x'} }, {
                { 'e', 'x', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'l', 't', 'x', 'h'} }};
        final int[][] location = _wordSearch.search(grid, "fine");
        assertNotNull(location);
        System.out.println(grid[0][0][0]);
        System.out.println(grid[1][0][0]);
        System.out.println(grid[2][0][0]);
        System.out.println(grid[3][0][0]);
        assertEquals(location[0][0], 0);
        assertEquals(location[0][1], 0);
        assertEquals(location[0][2], 0);
        assertEquals(location[1][0], 1);
        assertEquals(location[1][1], 0);
        assertEquals(location[1][2], 0);
        assertEquals(location[2][0], 2);
        assertEquals(location[2][1], 0);
        assertEquals(location[2][2], 0);
        assertEquals(location[3][0], 3);
        assertEquals(location[3][1], 0);
        assertEquals(location[3][2], 0);
    }

    @Test

    /**
     * Verifies that word search can return the word in the correct location
     * In this case, the word is backwards so making sure that reverse methods work
     *us (0,1, 1) (0,1,0)
     */

    public void testSearchComplex5 () {
        final char[][][] grid = new char[][][] { {
                { 'f', 'b', 'x', 'x'}, {'s', 'u', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'x', 't', 'x', 's'} }, {
                { 'i', 'o', 'x', 'x'}, {'x', 'i', 'x', 'x'}, {'x', 'x', 'e', 'x'}, {'x', 's', 's', 'x'} }, {
                { 'n', 'y', 'x', 'x'}, {'o', 'y', 'x', 'x'}, {'p', 'x', 's', 'x'}, {'e', 'e', 'x', 'x'} }, {
                { 'e', 'x', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'l', 't', 'x', 'h'} }};
        final int[][] location = _wordSearch.search(grid, "us");
        assertNotNull(location);
        assertEquals(location[0][0], 0);
        assertEquals(location[0][1], 1);
        assertEquals(location[0][2], 1);
        assertEquals(location[1][0], 0);
        assertEquals(location[1][1], 1);
        assertEquals(location[1][2], 0);
    }

    @Test
    /**
     * Verifies that word search can return the word in the correct location
     * In this case, the word is diagonal (2d)-- testing the 2d function
     *fuxs (0,0,0) (0,1,1) (0,2,2) (0,3,3)
     */

    public void testSearchComplex6 () {
        final char[][][] grid = new char[][][] { {
                { 'f', 'b', 'x', 'x'}, {'s', 'u', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'x', 't', 'x', 's'} }, {
                { 'i', 'o', 'x', 'x'}, {'x', 'i', 'x', 'x'}, {'x', 'x', 'e', 'x'}, {'x', 's', 's', 'x'} }, {
                { 'n', 'y', 'x', 'x'}, {'o', 'y', 'x', 'x'}, {'p', 'x', 's', 'x'}, {'e', 'e', 'x', 'x'} }, {
                { 'e', 'x', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'l', 't', 'x', 'h'} }};
        final int[][] location = _wordSearch.search(grid, "fuxs");
        assertNotNull(location);
        assertEquals(location[0][0], 0);
        assertEquals(location[0][1], 0);
        assertEquals(location[0][2], 0);
        assertEquals(location[1][0], 0);
        assertEquals(location[1][1], 1);
        assertEquals(location[1][2], 1);
        assertEquals(location[2][0], 0);
        assertEquals(location[2][1], 2);
        assertEquals(location[2][2], 2);
        assertEquals(location[3][0], 0);
        assertEquals(location[3][1], 3);
        assertEquals(location[3][2], 3);
    }

    @Test
    /**
     * Verifies that word search can return the word in the correct location (another reverse one)
     * less (3, 3, 0) (2, 3, 1) (1, 3, 2) (0, 3, 3)
     */

    public void testSearchComplex7 () {
        final char[][][] grid = new char[][][] { {
                { 'f', 'b', 'x', 'x'}, {'s', 'u', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'x', 't', 'x', 's'} }, {
                { 'i', 'o', 'x', 'x'}, {'x', 'i', 'x', 'x'}, {'x', 'x', 'e', 'x'}, {'x', 's', 's', 'x'} }, {
                { 'n', 'y', 'x', 'x'}, {'o', 'y', 'x', 'x'}, {'p', 'x', 's', 'x'}, {'e', 'e', 'x', 'x'} }, {
                { 'e', 'x', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'l', 't', 'x', 'h'} }};
        final int[][] location = _wordSearch.search(grid, "less");
        assertNotNull(location);
        assertEquals(location[0][0], 3);
        assertEquals(location[0][1], 3);
        assertEquals(location[0][2], 0);
        assertEquals(location[1][0], 2);
        assertEquals(location[1][1], 3);
        assertEquals(location[1][2], 1);
        assertEquals(location[2][0], 1);
        assertEquals(location[2][1], 3);
        assertEquals(location[2][2], 2);
        assertEquals(location[3][0], 0);
        assertEquals(location[3][1], 3);
        assertEquals(location[3][2], 3);
    }

    @Test
    /**
     * Verifies that word search can return the word in the correct location (2d one)
     *  ioz (1, 0, 0) (2, 1, 0) (3, 2, 0)
     */

    public void testSearchComplex8 () {
        final char[][][] grid = new char[][][] { {
                { 'f', 'b', 'x', 'x'}, {'s', 'u', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'x', 't', 'x', 's'} }, {
                { 'i', 'o', 'x', 'x'}, {'x', 'i', 'x', 'x'}, {'x', 'x', 'e', 'x'}, {'x', 's', 's', 'x'} }, {
                { 'n', 'y', 'x', 'x'}, {'o', 'y', 'x', 'x'}, {'p', 'x', 's', 'x'}, {'e', 'e', 'x', 'x'} }, {
                { 'e', 'x', 'x', 'x'}, {'x', 'x', 'x', 'x'}, {'z', 'x', 'x', 'x'}, {'l', 't', 'x', 'h'} }};
        final int[][] location = _wordSearch.search(grid, "ioz");
        assertNotNull(location);
        assertEquals(location[0][0], 1);
        assertEquals(location[0][1], 0);
        assertEquals(location[0][2], 0);
        assertEquals(location[1][0], 2);
        assertEquals(location[1][1], 1);
        assertEquals(location[1][2], 0);
        assertEquals(location[2][0], 3);
        assertEquals(location[2][1], 2);
        assertEquals(location[2][2], 0);
    }
    @Test
    /**
     * verifies that words are in a grid created by make
     */

    public void testSearchByMaking () {
        String[] words = new String[] { "hello", "hey", "15", "1 guy", "nation"};
        final char[][][] grid = _wordSearch.make(words, 4,5,6);
        final int[][] location1 = _wordSearch.search(grid, "1 guy");
        final int[][] location2 = _wordSearch.search(grid, "hello");
        final int[][] location3 = _wordSearch.search(grid, "nation");
        assertNotNull(location1);
        assertNotNull(location2);
        assertNotNull(location3);
    }


    @Before
    public void setUp () {
        _wordSearch = new WordSearch3D();
    }
}
