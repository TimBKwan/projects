import java.util.Random;
import java.util.*;
import java.io.*;
import java.util.Random;

/**
 * Luke Deratzou and Tim Kwan
 * Implements a 3-d word search puzzle program.
 */
public class WordSearch3D {
    public WordSearch3D () {
    }

    /**
     * Searches for all the words in the specified list in the specified grid.
     * You should not need to modify this method.
     * @param grid the grid of characters comprising the word search puzzle
     * @param words the words to search for
     * @return a list of lists of locations of the letters in the words
     */
    public int[][][] searchForAll (char[][][] grid, String[] words) {
        final int[][][] locations = new int[words.length][][];
        for (int i = 0; i < words.length; i++) {
            locations[i] = search(grid, words[i]);
        }
        return locations;
    }

    /**
     * Searches for the specified word in the specified grid.
     * @param grid the grid of characters comprising the word search puzzle
     * @param word the word to search for
     * @return If the grid contains the
     * word, then the method returns a list of the (3-d) locations of its letters; if not, return null
     */
    public int[][] search (char[][][] grid, String word) {
        if (isSearchNull(grid, word)) {
            return null;
        }
        if (word.isEmpty()) {
            return new int[0][0];
        }
        return testDirections(grid, word);

    }

    /**
     * tests each possible direction that a word can be present at, then produces location of word if found
     * @param grid the grid of characters comprising the word search puzzle
     * @param word the word to search for
     * @return the location of the word if it is in the grid, otherwise it returns null
     */
    private int[][] testDirections (char[][][] grid, String word) {
        for (int i=-1; i<2; i++) {
            for(int j=-1; j<2; j++) {
                for(int k=-1; k<2; k++) {
                    if (!(k == 0 && j == 0 && i == 0)) {
                        final int[][] theSearch = searchAllDirs(grid, word, new int[] {i,j,k});
                        if (theSearch != null) {
                            return theSearch;
                        }
                    }
                }
            }
        }
        return null;
    }

    /**
     * Checks if the i j and k are valid bounds. Error-checking
     * A valid bound has all three values be positive and smaller than grid length
     * @param grid the grid of characters comprising the word search puzzle
     * @param values the i, j, and k values
     * @return true if it is a valid bound, false if not
     */
    private boolean isInBounds(char[][][] grid, int[] values) {
        final boolean check1 = grid.length > values[0] && grid[0].length > values[1] && grid[0][0].length > values[2];
        final boolean check2 = values[0] >= 0 && values[1] >= 0 && values[2] >= 0; //all indexes must be positive
        return check1 && check2;
    }


    /**
     * For each direction (indicated by increments array), search for word in word search grid
     * @param grid the grid of characters comprising the word search puzzle
     * @param word the word to search for
     * @param increments the "direction" that is being traveled. Indicated with a -1, 0, or 1.
     *                   One for each coordinate (x,y,z)
     * @return the location of the word if found, otherwise return null
     */

    private int[][] searchAllDirs (char[][][] grid, String word, int[] increments) {
        for(int i=0; i<grid.length; i++) {
            for(int j=0; j<grid[i].length; j++) {
                for(int k=0; k<grid[i][j].length; k++) {
                    String tempWord = "";
                    final int locationLength = Integer.max(Integer.max(grid.length, grid[i].length), grid[i][j].length);
                    //above uses .max for out-of-bounds error-checking; need max of all 3 "directions"
                    int[][] tempLocation = new int[locationLength][3];
                    int a = i;
                    int b = j;
                    int c = k;
                    int counter = 0; //# of times went through while loop; used for tempLocation indexing
                    while(isInBounds(grid, new int[] {a, b, c})) { //similar to for loop but 1-3 ints change simultaneously
                        tempWord += grid[a][b][c];
                        tempLocation[counter][0] = a;
                        tempLocation[counter][1] = b;
                        tempLocation[counter][2] = c;
                        if(tempWord.contains(word)) {
                            return formattedLocation(word, tempWord, tempLocation);
                        }
                        a = a + increments[0];
                        b = b + increments[1];
                        c = c + increments[2];
                        counter++;
                    }
                }
            }
        }
        return null;
    }


    /**
     * Checks where the word is in tempWord, then returns the location based on index manipulation
     * @param word the word to search for
     * @param tempWord the word that was found. Includes other characters in same "line"
     * @param tempLocation the location of the word that was found. Includes locations of other characters
     *                     in same "line"
     * @return the correct location for the word
     */

    private int[][] formattedLocation (String word, String tempWord, int[][] tempLocation) {
        final int[][] location = new int[word.length()][3];
        final int s = tempWord.indexOf(word);
        for (int i=0; i<word.length(); i++) {
            location[i] = tempLocation[i+s];
        }
        return location;
    }

    /**
     * Handles two of the initial edge cases of the search method
     * @param grid the grid of characters comprising the word search puzzle
     * @param word the word to search for
     * @return If the word is null or its length exceeds any one of the grid's lengths, return true
     * else return false
     */
    private boolean isSearchNull (char[][][] grid, String word) {
        if (word == null) {
            return true;
        }
        int maxSize = Integer.max(grid.length, grid[0].length);
        maxSize = Integer.max(maxSize, grid[0][0].length);
        return maxSize < word.length();

    }

    /**
     * Tries to create a word search puzzle of the specified size with the specified
     * list of words.
     * @param words the list of words to embed in the grid
     * @param sizeX size of the grid along first dimension
     * @param sizeY size of the grid along second dimension
     * @param sizeZ size of the grid along third dimension
     * @return a 3-d char array if successful that contains all the words, or <tt>null</tt> if
     * no satisfying grid could be found.
     */
    public char[][][] make (String[] words, int sizeX, int sizeY, int sizeZ) {
        if (sizeX <= 0 || sizeY <= 0 || sizeZ <= 0) {
            //invalid size check
            return null;
        }
        for(int i=0; i<1000; i++) {
            final char[][][] grid = makeNewBoard(words, sizeX, sizeY, sizeZ);
            if (grid != null) {
                return populateGrid(grid);
            }
        }
        return null;
    }

    /**
     * inserts random lowercase letters into word search grid
     * @param grid the grid of characters comprising the word search puzzle
     * @return a grid filled with the random lowercase letters along with the words
     */

    private char[][][] populateGrid (char[][][] grid) {
        for (int i = 0; i <grid.length; i++) {
            for (int j = 0; j < grid[i].length; j++) {
                for (int k = 0; k < grid[i][j].length; k++) {
                    if (grid[i][j][k] == 0) {
                        final Random rng = new Random();
                        final char randomLetter = (char) (rng.nextInt(26) + 'a');
                        grid[i][j][k] = randomLetter;
                    }
                }
            }
        }
        return grid;

    }
    
    /**
     * makes a fresh board of given size and attempts to populate it with the list of words
     * @param words the list of words to embed in the grid
     * @param sizeX size of the grid along first dimension
     * @param sizeY size of the grid along second dimension
     * @param sizeZ size of the grid along third dimension
     * @return a 3-d char array if successful that contains all the words, or null if
     * no satisfying grid could be found with the current attempt.
     */

    private char[][][] makeNewBoard (String[] words, int sizeX, int sizeY, int sizeZ) {
        char[][][] grid = new char[sizeX][sizeY][sizeZ];
        final ArrayList<String> addedWords = new ArrayList<String>(); //list of words already added to grid
        for(String s: words) {
            grid = insertWordIntoGrid(s, grid, addedWords);
            if(grid == null) {
                return null;
            }
            addedWords.add(s);
        }
        return grid;
    }


    /**
     * tries 1000 times to add a word to the grid, using random position & direction
     * @param word the word that is trying to be added to the grid
     * @param grid the 3d array of characters where words will be added
     * @param addedWords the words that were already added to the grid
     * @return the grid of words if the word was successfully added; otherwise returns null if it failed
     */
    private char[][][] insertWordIntoGrid (String word, char[][][] grid, ArrayList<String> addedWords) {
        for (int i=0; i<1000; i++) {
            final Random rng = new Random();
            final int randomPositionX = rng.nextInt(grid.length);
            final int randomPositionY = rng.nextInt(grid[0].length);
            final int randomPositionZ = rng.nextInt(grid[0][0].length);
            final int[] randomStartPosition = new int[] { randomPositionX, randomPositionY, randomPositionZ};
            final int randomOffsetX = rng.nextInt(3)-1; //how much change will occur in the x
            final int randomOffsetY = rng.nextInt(3)-1; //y
            final int randomOffsetZ = rng.nextInt(3)-1; //z direction for each new position. either -1, 0, or 1
            final int[][] location = createLocation(randomStartPosition, randomOffsetX, randomOffsetY, randomOffsetZ, word.length());
            if (isValidLocation(location, grid) && isValidOffsets(randomOffsetX, randomOffsetY, randomOffsetZ)) {
                final char[][][] newGrid = insertWord(grid, location, word);
                if (arePriorWordsStillPresent(newGrid, addedWords)) {
                    return newGrid;
                }

            }

        }
        return null;
    }

    /**
     * checks if the offsets are valid, as if they are all zero it won't work
     * @param xOffset the change in the x coordinate each iteration of for loop
     * @param yOffset the change in the y coordinate each iteration of for loop
     * @param zOffset the change in the z coordinate each iteration of for loop
     * @return false if all 3 offsets equal zero, true otherwise
     */

    private boolean isValidOffsets(int xOffset, int yOffset, int zOffset) {
        final boolean test1 = xOffset == 0;
        final boolean test2 = yOffset == 0;
        final boolean test3 = zOffset == 0;
        return !(test1 && test2 && test3); //if all three are zero, then will put characters all in same space
    }

    /**
     * creates a location based on the start position and offsets
     * @param startPos the starting position of the word (x,y,z)
     * @param xOffset the change in the x coordinate each iteration of for loop
     * @param yOffset the change in the y coordinate each iteration of for loop
     * @param zOffset the change in the z coordinate each iteration of for loop
     * @param wordLength the length of the word
     * @return the location that the word will potentially be put in
     */
    private int[][] createLocation (int[] startPos, int xOffset, int yOffset, int zOffset, int wordLength) {
        final int[][] wordLocation = new int[wordLength][3];
        wordLocation[0] = startPos;
        for(int i=1; i<wordLength; i++) {
            wordLocation[i][0] = wordLocation[i-1][0] + xOffset;
            wordLocation[i][1] = wordLocation[i-1][1] + yOffset;
            wordLocation[i][2] = wordLocation[i-1][2] + zOffset;
        }
        return wordLocation;
    }

    /**
     * checks if the location that the word will be placed is valid
     * @param location the location that the word will potentially be placed
     * @param grid the grid of chars that will be placed there maybe
     * @return whether or not it is a valid location
     */
    private boolean isValidLocation (int[][] location, char[][][] grid) {
        final boolean isPositive = location[location.length-1][0] >= 0
                && location[location.length-1][1] >= 0 && location[location.length-1][2] >= 0;
        final boolean isInBounds = location[location.length-1][0] < grid.length
                && location[location.length-1][1] < grid[0].length && location[location.length-1][2] < grid[0][0].length;
        return isPositive && isInBounds;
    }

    /**
     * inserts a word into the grid
     * @param grid the grid of characters, where words will be added
     * @param location the location where the word will be added
     * @param word the word that will be added
     * @return returns the grid with the word inserted at the specified position
     */

    private char[][][] insertWord (char[][][] grid, int[][] location, String word) {
        final char[][][] newGrid = new char[grid.length][grid[0].length][grid[0][0].length];
        for (int i=0; i<grid.length; i++) {
            for (int j=0; j<grid[i].length; j++) {
                for(int k=0; k<grid[i][j].length; k++) {
                    newGrid[i][j][k] = grid[i][j][k];
                }
            }
        }
        for (int i = 0; i < location.length; i++) {
            newGrid[location[i][0]][location[i][1]][location[i][2]] = word.charAt(i);
        }
        return newGrid;
    }

    /**
     * checks if the priory- added words are still in the grid
     * @param grid the grid of characters where words will be added
     * @param addedWords the words that were already added to the grid
     *                   (but might have been lost to the newly added word)
     * @return true if the grid still has all the old words, false if its missing at least one
     */
    private boolean arePriorWordsStillPresent (char[][][] grid, ArrayList<String> addedWords) {
        for(String s: addedWords) {
            if (search(grid, s) == null) {
                return false;
            }
        }
        return true;
    }

    /**
     * Exports to a file the list of lists of 3-d coordinates.
     * You should not need to modify this method.
     * @param locations a list (for all the words) of lists (for the letters of each word) of 3-d coordinates.
     * @param filename what to name the exported file.
     */
    public static void exportLocations (int[][][] locations, String filename) {
        // First determine how many non-null locations we have
        int numLocations = 0;
        for (int i = 0; i < locations.length; i++) {
            if (locations[i] != null) {
                numLocations++;
            }
        }

        try (final PrintWriter pw = new PrintWriter(filename)) {
            pw.print(numLocations);  // number of words
            pw.print('\n');
            for (int i = 0; i < locations.length; i++) {
                if (locations[i] != null) {
                    pw.print(locations[i].length);  // number of characters in the word
                    pw.print('\n');
                    for (int j = 0; j < locations[i].length; j++) {
                        for (int k = 0; k < 3; k++) {  // 3-d coordinates
                            pw.print(locations[i][j][k]);
                            pw.print(' ');
                        }
                    }
                    pw.print('\n');
                }
            }
            pw.close();
        } catch (FileNotFoundException fnfe) {
            fnfe.printStackTrace();
        }
    }

    /**
     * Exports to a file the contents of a 3-d grid.
     * You should not need to modify this method.
     * @param grid a 3-d grid of characters
     * @param filename what to name the exported file.
     */
    public static void exportGrid (char[][][] grid, String filename) {
        try (final PrintWriter pw = new PrintWriter(filename)) {
            pw.print(grid.length);  // height
            pw.print(' ');
            pw.print(grid[0].length);  // width
            pw.print(' ');
            pw.print(grid[0][0].length);  // depth
            pw.print('\n');
            for (int x = 0; x < grid.length; x++) {
                for (int y = 0; y < grid[0].length; y++) {
                    for (int z = 0; z < grid[0][0].length; z++) {
                        pw.print(grid[x][y][z]);
                        pw.print(' ');
                    }
                }
                pw.print('\n');
            }
            pw.close();
        } catch (FileNotFoundException fnfe) {
            fnfe.printStackTrace();
        }
    }

    /**
     * Creates a 3-d word search puzzle with some nicely chosen fruits and vegetables,
     * and then exports the resulting puzzle and its solution to grid.txt and locations.txt
     * files.
     */
    public static void main (String[] args) {
        final WordSearch3D wordSearch = new WordSearch3D();
        final String[] words = new String[] { "apple", "orange", "pear", "peach", "durian", "lemon", "lime", "jackfruit", "plum", "grape", "apricot", "blueberry", "tangerine", "coconut", "mango", "lychee", "guava", "strawberry", "kiwi", "kumquat", "persimmon", "papaya", "longan", "eggplant", "cucumber", "tomato", "zucchini", "olive", "pea", "pumpkin", "cherry", "date", "nectarine", "breadfruit", "sapodilla", "rowan", "quince", "toyon", "sorb", "medlar" };
        final int xSize = 10, ySize = 10, zSize = 10;
        final char[][][] grid = wordSearch.make(words, xSize, ySize, zSize);
        exportGrid(grid, "grid.txt");

        final int[][][] locations = wordSearch.searchForAll(grid, words);
        exportLocations(locations, "locations.txt");
    }
}
