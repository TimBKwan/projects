
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

/**
 * Class that implements a ball with a position and velocity.
 */
public class Ball {
	// Constants
	/**
	 * The radius of the ball.
	 */
	private static final int BALL_RADIUS = 8;

	private double xRightAsymptote;
	private double xLeftAsmptote;
	private double yTopAsmptote;
	private double yBottomAsmptote;

	/**
	 * The initial velocity of the ball in the x direction.
	 */
	private static final double INITIAL_VX = 1e-7;
	/**
	 * The initial velocity of the ball in the y direction.
	 */
	private static final double INITIAL_VY = 1e-7;

	// Instance variables
	// (x,y) is the position of the center of the ball.
	private double x, y;
	private double vx, vy;
	private Circle circle;

	/**
	 * @return the Circle object that represents the ball on the game board.
	 */
	public Circle getCircle() {
		return circle;
	}

	/**
	 * Constructs a new Ball object at the centroid of the game board
	 * with a default velocity that points down and right.
	 */
	public Ball() {
		x = GameImpl.WIDTH / 2;
		y = GameImpl.HEIGHT / 2;
		vx = INITIAL_VX;
		vy = INITIAL_VY;

		circle = new Circle(BALL_RADIUS, BALL_RADIUS, BALL_RADIUS);
		circle.setLayoutX(x - BALL_RADIUS);
		circle.setLayoutY(y - BALL_RADIUS);
		circle.setFill(Color.BLACK);
	}

	/**
	 * Updates the position of the ball, given its current position and velocity,
	 * based on the specified elapsed time since the last update.
	 * @param deltaNanoTime the number of nanoseconds that have transpired since the last update
	 */
	public void updatePosition(long deltaNanoTime) {
		double dx = vx * deltaNanoTime;
		double dy = vy * deltaNanoTime;
		x += dx;
		y += dy;

		circle.setTranslateX(x - (circle.getLayoutX() + BALL_RADIUS));
		circle.setTranslateY(y - (circle.getLayoutY() + BALL_RADIUS));


		//Updates Collision Borders of Ball
		xLeftAsmptote = x - BALL_RADIUS;
		xRightAsymptote = x + BALL_RADIUS;
		yBottomAsmptote = y + BALL_RADIUS;
		yTopAsmptote = y - BALL_RADIUS;
		borderCollide();


	}

	/*
	 *Checks if the ball collides with the border
	 *
	 * If border collision occurs then the balls goes the opposite direction
	 * relative to the direction it collides in.
	 */
	private void borderCollide() {
		final double width = GameImpl.WIDTH;
		if ((xLeftAsmptote <= 0 && vx < 0)|| (xRightAsymptote >= width && vx > 0)) {
			vx = -vx;
		}
		if (yTopAsmptote <= 0 && vy < 0 ) {
			vy = -vy;
		}

	}

	/**
	 *Checks if the ball collides with the lower wall of the game
	 *in order to know when to decrease the lives by one.
	 * Reverses the y velocity if collision occurs with the lower wall
	 * @return returns true if it does and false otherwise
	 */
	public boolean lowerWall(){
		final double height = GameImpl.HEIGHT;
		if(yBottomAsmptote >= height && vy > 0){
					vy = -vy;
					return true;

		}
		return false;
	}

	/*
	 *Increases the velocity of the ball by 1.1
	 */
	public void makeFaster(){
		vy = vy*1.1;
		vx = vx*1.1;
	}

	/**
	 *Checks for collision with images.
	 * If collision occurs, the y velocity is reversed
	 * @param coordinates of each corner of the image
	 * @return returns true if ball collides with an image, returns false otherwise
	 */
	public boolean Collide(double[][] coordinates){

		double yBottomObstacle = coordinates[2][1];
		double yTopObstacle  = coordinates[0][1];
		double xLeftObstacle = coordinates[0][0];
		double xRightObstacle = coordinates[1][0];

		if ((yBottomAsmptote >= yTopObstacle && yBottomAsmptote <= yBottomObstacle) || (yTopAsmptote <= yBottomObstacle && yTopAsmptote >= yTopObstacle)) {
			if ((xLeftAsmptote >= xLeftObstacle && xLeftAsmptote <= xRightObstacle) || (xRightAsymptote <= xRightObstacle && xRightAsymptote >= xLeftObstacle)) {
				vy = -vy;
				return true;

			}
		}
		return false;

	}
}
