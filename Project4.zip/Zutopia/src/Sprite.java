import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * Class that implements a sprite that represents an image on the scene
 */
public class Sprite{

    private ImageView view;                 //ImageView variable that holds the image
    private final double[][] Coordinates;   //2D array that holds the Coordinates of teh corners of the images

    /**
     * Constructor sets the image
     * @param url sets image with given url that is a string
     * @param x   x position of the image
     * @param y   y position of the image
     */
    public Sprite(String url, double x, double y){
        setImage(url, x, y);
        Coordinates = makeCoordinates();
    }

    /**
     * @return the double array of coordinates
     */
    public double[][] getCoordinates() {
        return Coordinates;
    }

    /**
     * Assigns the physical features of the image
     * @param url url of the image to load
     * @param x x position of the image
     * @param y y position of the image
     */
     private void setImage(String url, double x, double y) {

        // simple displays ImageView the image as is
        ImageView view = new ImageView();
        Image image = new Image(url);
        view.setLayoutX(x);
        view.setLayoutY(y);
        view.setFitHeight(50);
        view.setFitWidth(50);
        view.setImage(image);
        this.view = view;

    }

    /**
     * @return returns the image view
     */
    public ImageView LoadImage(){
        return this.view;
    }

    /**
     * Creates the border coordinates of the image
     * @return a double array of the 4 border coordinates
     */
    private double[][] makeCoordinates(){
        final double LeftSide = view.getLayoutX();
        final double RightSide= view.getLayoutX() + view.getFitWidth();
        final double TopSide = view.getLayoutY();
        final double BottomSide= view.getLayoutY() + view.getFitHeight();
        final double[][] imageCoordinate = new double[4][2];
        imageCoordinate[0][0] = LeftSide ;
        imageCoordinate[0][1] = TopSide;
        imageCoordinate[1][0] = RightSide;
        imageCoordinate[1][1] = TopSide;
        imageCoordinate[2][0] = LeftSide ;
        imageCoordinate[2][1] = BottomSide;
        imageCoordinate[3][0] = RightSide;
        imageCoordinate[3][1] = BottomSide;
        return imageCoordinate;
    }
}
