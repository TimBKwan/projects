/**
 * Starter code to implement an ExpressionParser. Your parser methods should use the following grammar:
 * E := A | X
 * A := A+M | M
 * M := M*M | X
 * X := (E) | L
 * L := [0-9]+ | [a-z]
 */
public class SimpleExpressionParser implements ExpressionParser {
	private CompoundExpression _parentTemp = null; //Temp for parent expression

	/**
	 * Attempts to create an expression tree -- flattened as much as possible -- from the specified String.
         * Throws a ExpressionParseException if the specified string cannot be parsed.
	 * @param str the string to parse into an expression tree
	 * @param withJavaFXControls you can just ignore this variable for R1
	 * @return the Expression object representing the parsed expression tree
	 */
	public Expression parse (String str, boolean withJavaFXControls) throws ExpressionParseException {
		// Remove spaces -- this simplifies the parsing logic
		str = str.replaceAll(" ", "");
		Expression expression = parseExpression(str);
		if (expression == null) {
			// If we couldn't parse the string, then raise an error
			throw new ExpressionParseException("Cannot parse expression: " + str);
		}

		// Flatten the expression before returning
		expression.flatten();
		return expression;
	}

	/**
	 * Parses only if the string is valid and returns an expression
	 * @param str
	 * @return an expression
	 */
	protected Expression parseExpression (String str) {

		// TODO implement me

		if (isValid(str) && isValidParanthesis(str)) { //check whether the string is valid
			return parseE(str);

		}
		else{
			System.out.println("invalid String");
			return null;
		}

	}

	/**
	 *Checks if addition, multiplication is valid
	 * @param str
	 * @return boolean, returns true or false if the string is a valid string to parse
	 */
	private boolean isValid(String str){
		if(str.length() == 0){
			return false;
		}
		boolean valid = true;
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) == '+'|| str.charAt(i) =='*') {

				if(isValid(str.substring(0, i)) /* before + */ && isValid(str.substring(i + 1))/* after + */) {
					valid = true;
				}
				else{
					valid = false;
				}
			}
		}

		return valid;
	}


	/**
	 * Checks if the expression follows paranthesis rules
	 * @param str
	 * @return boolean, returns true if paranthesis are used correctly
	 */
	private boolean isValidParanthesis(String str) {
		int paranthesisCount = 0;



		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) == '(' ) {
				if(i< str.length()-1 && str.charAt(i+1) == ')'){
					return false;
				}
				paranthesisCount++;

			}
			if (str.charAt(i) == ')' ) {
				if(i< str.length()-1 && str.charAt(i+1) == '('){
					return false;
				}
				paranthesisCount--;
				if(paranthesisCount < 0){
					return false;
				}
			}
		}
		return (paranthesisCount == 0);
	}

	/**
	 * Checks if string is an integer
	 * @param str
	 * @return true if the string is an integer
	 */
	private boolean isNumber(String str) {
		//check [0-9]

				try{
					int stringToNumber = Integer.parseInt(str);
					return true;
				}
				catch (Exception e){

		return false;
	}}


	/**
	 * Parses the string into an expression tree. Splits it up by operations.
	 * @param str
	 * @return a parsed expression
	 */
	private Expression parseE(String str){

		int paranthesisCounter = 0; //amount of paranthesis in expression to make sure to not parse inside paranthesis

		//checking if string is number
		if(isNumber(str)){
			LiteralExpression literal = new LiteralExpression();
			literal.set_identity(str);
			literal.setParent(_parentTemp); //setting parent as the previous operation node
			return literal;

		}

		//Check if string is literal
		if(str.length() == 1){
			char character = str.charAt(0);
			if(Character.isLetter(character)){
				LiteralExpression literal = new LiteralExpression();
				literal.set_identity(str);
				literal.setParent(_parentTemp); //setting parent as the previous operation node
				return literal;
			}
		}


		// Check E+E
		for (int i = 0; i < str.length(); i++) {

			if(str.charAt(i) =='('){
				paranthesisCounter++;
			}
			if(str.charAt(i)==')'){
				paranthesisCounter--;
			}
			if (str.charAt(i) == '+' && paranthesisCounter==0) {
				OperationExpression operation = new OperationExpression();
				operation.set_identity("+");

				if(_parentTemp != null ){
					operation.setParent(_parentTemp);
				}

				_parentTemp = operation; //saving the operation node as a temporary parent
				operation.addSubexpression(parseE(str.substring(0, i))); //recursively call parseE to complete the tree
				operation.addSubexpression(parseE(str.substring(i+1)));
				return operation;

			}

		}

		//Check E*E
		for (int i = 0; i < str.length()-1 ; i++) {
			if(str.charAt(i) =='('){
				paranthesisCounter++;
			}
			if(str.charAt(i)==')'){
				paranthesisCounter--;
			}
			if(paranthesisCounter==0) {

				if (str.charAt(i) == '*') {
					OperationExpression operation = new OperationExpression();
					operation.set_identity("*");
					if(_parentTemp != null ){
						operation.setParent(_parentTemp);
					}

					_parentTemp = operation;  //saving the operation node as a temporary parent
					operation.addSubexpression(parseE(str.substring(0, i)));
					operation.addSubexpression(parseE(str.substring(i + 1)));
					return operation;


				}
			}

		}

		if(str.charAt(0) == '(' && str.charAt(str.length()-1)== ')'){
			OperationExpression operation = new OperationExpression();
			operation.set_identity("()");
			if(_parentTemp != null ){
				operation.setParent(_parentTemp);
			}

			_parentTemp = operation;  //saving the operation node as a temporary parent
			operation.addSubexpression(parseE(str.substring(1,str.length()-1)));
			return operation;

		}


		return null;

	}


}
