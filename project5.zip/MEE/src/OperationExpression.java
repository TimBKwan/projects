import java.util.ArrayList;
import java.util.List;

public class OperationExpression implements CompoundExpression {

    private List<OperationExpression> visitedOperationList = new ArrayList<>();
    private OperationExpression _parent;
    public String _identity;
    private List<Expression> children = new ArrayList<>();

    public String get_identity(){
        return _identity;
    }

    public void set_identity(String identity) {
        _identity = identity;

    }

    @Override
    public void addSubexpression(Expression subexpression) {
        children.add(subexpression);

    }

    @Override
    public CompoundExpression getParent() {
        return _parent;
    }

    @Override
    public void setParent(CompoundExpression parent) {
        _parent = (OperationExpression) parent;

    }

    @Override
    public Expression deepCopy() {
        return null;
    }

    @Override
    public void flatten() {

        for (int i = 0; i < children.size(); i++) {
            Expression child = children.get(i);
            if(child instanceof OperationExpression){

                OperationExpression operationChild = (OperationExpression) child;
                String childName = operationChild._identity;


                if(childName.equals(_identity)){
                    for (Expression grandChild: operationChild.children) {

                        operationChild._parent.addSubexpression(grandChild);
                        grandChild.setParent(operationChild._parent);

                    }
                    children.remove(child);


                }

                // _parent.addSubexpression(child);
                // child.setParent(_parent);

             }
            children.get(i).flatten();
        }

    }

    @Override
    public void convertToString(StringBuilder stringBuilder, int indentLevel) {
        Expression.indent(stringBuilder,indentLevel);
        stringBuilder.append(_identity + "\n");
        int newlevel = indentLevel + 1;
        for (Expression child : children) {
            String childA = child.convertToString(newlevel);
            stringBuilder.append(childA);


        }

    }
//

}
