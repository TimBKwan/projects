

public class LiteralExpression implements Expression {

    private  CompoundExpression _parent;
    private String _identity; //Name of literal expression


    /**
     * Sets the identity of the literal expression
     * @param identity
     */
    public void set_identity(String identity) {
        _identity = identity;

    }


    public CompoundExpression getParent() {

        return _parent;
    }


    public void setParent(CompoundExpression parent) {
        _parent = parent;

    }

    public Expression deepCopy() {
        return null;
    }


    public void flatten() {
    }

    public void convertToString(StringBuilder stringBuilder, int indentLevel) {
        Expression.indent(stringBuilder, indentLevel);
        stringBuilder.append(_identity + "\n");
    }


}
