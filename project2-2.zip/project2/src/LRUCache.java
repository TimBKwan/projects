import java.util.HashMap;
/**
 * An implementation of <tt>Cache</tt> that uses a least-recently-used (LRU)
 * eviction policy.
 */
public class LRUCache<T, U> implements Cache<T, U> {
    /**
     * a linked list of Nodes for keeping track of cache order
     * @param <T> the key
     * @param <U> the value
     */
    private static class SingularlyLinkedList<T,U> {
        private Node<T,U> _head, _tail;
        /**
         * removes a node from the linked list
         * @param node the node that will be removed
         */
        private void remove(Node<T, U> node) {
            if (node._prev == null) { //if the previous of node was null, the node was the head
                node._next._prev = null;
                _head = node._next;
            } else if (node._next == null) { //if the next of the node was null, the node was the tail
                node._prev._next = null;
                _tail = node._prev;
            } else {
                node._prev._next = node._next;
                node._next._prev = node._prev;
            }
        }
        /**
         * inserts a node to the end of the linked list
         * @param newNode the node that will be added
         */
        private void addToEnd(Node<T, U> newNode) {
            final Node<T,U> node = newNode;
            if (_head == null) {
                _head = node;
                _tail = node;
            } else {
                _tail._next = node;
                _tail = node;
            }
        }
        /**
         * removes the first node of the linked list by setting the old head to be null and
         * assigning the head's next element as the new head
         * @return the node that was removed
         */
        private Node<T,U> removeFirst() {
            try {
                final Node<T, U> removedNode = new Node<> (_head._key, _head._value, null);
                _head._next._prev = null;
                _head = _head._next;
                return removedNode;
            } catch (Exception e){
                //this catch will only be executed if capacity = 1 (as head will not have a next).
                //so this deals with the corner-case of having a lru cache of cap=1
                final Node<T, U> removedNode = new Node<> (_head._key, _head._value, null);
                _head = null;
                return removedNode;
            }
        }
    }
    /**
     * a node for the linked list, which contains the key, value, and next node
     * @param <T> the key
     * @param <U> the value
     */
    private static class Node<T, U> {
        private T _key;
        private U _value;
        private Node<T,U> _next;
        private Node<T, U> _prev;
        /**
         * the node constructor
         * (next is null as node's are usually created to be inserted at the end of linked list)
         * @param key the key of the node
         * @param value the value of the node
         */
        private Node(T key, U value, Node<T,U> prev) {
            _key = key;
            _value = value;
            _next = null;
            _prev = prev;
        }
    }
    private int _capacity;
    private DataProvider<T, U> _provider;
    private HashMap<T, Node<T,U>> _hashMap;
    private SingularlyLinkedList<T, U> _linkedList;
    private int _misses;
    private Node<T,U> _prevNode;
    /**
     * @param provider the data provider to consult for a cache miss
     * @param capacity the exact number of (key,value) pairs to store in the cache
     */
    public LRUCache (DataProvider<T, U> provider, int capacity) {
        _provider = provider;
        _capacity = capacity;
        _hashMap = new HashMap<>(capacity);
        _linkedList = new SingularlyLinkedList<>();
        _prevNode = null; //keeps track of previously added element to the hashmap/linkedlist
    }
    /**
     * Returns the value associated with the specified key.
     * @param key the key
     * @return the value associated with the key
     */
    public U get (T key) {
        if (_capacity == 0) { //edge case of capacity = 0, we just have to fetch from provider every time
            _misses++;
            return _provider.get(key);
        } else if (_capacity < 0) { //edge case of capacity being invalid number, we just return null
            return null;
        } else if (_prevNode != null &&_prevNode._key.equals(key)) { //case when key was just added to the cache
            return _hashMap.get(key)._value; //so just return the value of the previous key (which is already at tail)
        } else if (_hashMap.containsKey(key)) { //if the hashmap already has the key...
            final Node<T, U> removedNode = _hashMap.remove(key);
            _linkedList.remove(removedNode); //...remove the key in the linked list (and hashmap)...
            final Node<T, U> newPair = new Node<>(key, removedNode._value, _prevNode);
            _hashMap.put(key, newPair);
            _linkedList.addToEnd(newPair); //..and add it to the hashmap and end of linked list
            _prevNode = newPair;
            return newPair._value;
        }
        _misses++; //do not continue if/else because for both of these cases, it is a miss. so saves a line of code.
        if (_hashMap.size() == _capacity) { //we gotta remove the last used element (element at head of linked list)!
            final Node<T,U> removedNode = _linkedList.removeFirst();
            final T keyToRemove = removedNode._key;
            _hashMap.remove(keyToRemove);
            //and add the new element to the hashmap and end of the linked list
            final U valueToAdd = _provider.get(key);
            final Node nodeToAdd = new Node<> (key, valueToAdd, _prevNode);
            _hashMap.put(key, nodeToAdd);
            _linkedList.addToEnd(nodeToAdd);
            _prevNode = nodeToAdd;
            return valueToAdd;
        } else { //other wise, we just add element to the hash map and end of the list
            final U valueToAdd = _provider.get(key);
            final Node<T,U> nodeToAdd = new Node<> (key, valueToAdd, _prevNode);
            _hashMap.put(key, nodeToAdd);
            _linkedList.addToEnd(nodeToAdd);
            _prevNode = nodeToAdd;
            return valueToAdd;
        }
    }
    /**
     * Returns the number of cache misses since the object's instantiation.
     * @return the number of cache misses since the object's instantiation.
     */
    public int getNumMisses () {
        return _misses;
    }
}