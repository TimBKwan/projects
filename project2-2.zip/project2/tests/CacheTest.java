import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.util.HashMap;

/**
 * Code to test an <tt>LRUCache</tt> implementation.
 */
public class CacheTest {
    /**
     * the class we created that implements DataProvider interface
     */
    private static class NegativeIntegerLoader implements DataProvider<Integer, Integer> {
        private HashMap<Integer, Integer> _integerTable;
        private int _numFetches;
        /**
         * constructor- inserted our data via for loop so we can have a large number of data in the provider without
         * writing thousands of lines. also easy to test significantly larger/smaller quantities (just change capacity)
         */
        private NegativeIntegerLoader() {
            _numFetches = 0;
            final int providerCapacity = 1000000;
            _integerTable = new HashMap<>(providerCapacity);
            for (int i=1; i<=providerCapacity; i++) {
                _integerTable.put(i, -i); //"-i" just to have a different number for the value part
            }
        }
        /**
         * the get method, implemented through DataProvider, which gets a value based on the key
         * @param s the key (a string)
         * @return the value associated with the key (an Integer)
         */
        public Integer get(Integer s) {
            _numFetches++;
            return _integerTable.get(s);
        }
        /**
         * produces the number of fetches, aka the number of times get() is called
         * @return the number of fetches
         */
        private int getNumFetches() {
            return _numFetches;
        }
    }
    @Test
    /**
     * Tests that a value can be added correctly to empty cache, and is not counted again same value is added again
     */
    public void testVerySimpleCache() {
        final NegativeIntegerLoader dp = new NegativeIntegerLoader();
        final Cache<Integer, Integer> cache = new LRUCache<>(dp, 4);
        cache.get(1);
        assertEquals(dp.getNumFetches(), 1);
        assertEquals(cache.getNumMisses(), 1);
        cache.get(1);
        assertEquals(dp.getNumFetches(), 1);
        assertEquals(cache.getNumMisses(), 1);
    }
    @Test
    /**
     * Tests that the cache will evict the least recent used key-value pair(the first fetched)
     * in this case, tests that the value with key 1 will be removed, therefore only five database fetches should happen
     * after one is called after four
     */
    public void testSimpleCacheEviction() {
        final NegativeIntegerLoader dp = new NegativeIntegerLoader();
        final Cache<Integer, Integer> cache = new LRUCache<>(dp, 3);
        cache.get(1);
        cache.get(2);
        cache.get(3);
        cache.get(4);
        cache.get(5);
        assertEquals(dp.getNumFetches(), 5);
        assertEquals(cache.getNumMisses(), 5);
    }
    @Test
    /**
     * Tests that the cache will correctly evict the value with the key "2"
     * as, despie 1 being added before 2, it was called after 2.
     */
    public void testLessSimpleCacheEviction() {
        final NegativeIntegerLoader dp = new NegativeIntegerLoader();
        final Cache<Integer, Integer> cache = new LRUCache<>(dp, 3);
        cache.get(1);
        cache.get(2);
        cache.get(1);
        cache.get(3);
        cache.get(4);
        cache.get(3);
        assertEquals(dp.getNumFetches(), 4);
        assertEquals(cache.getNumMisses(), 4);
    }

    /**
     * Tests an edge case where the capacity is one and a large number of entries of unique values are being added
     */
    @Test
    public void capacityLotsOfEntries() {
        final NegativeIntegerLoader dp = new NegativeIntegerLoader();
        final Cache<Integer, Integer> cache = new LRUCache<>(dp, 1);
        final int valuesToAdd = 100000;
        for(int i=1; i<=valuesToAdd; i++) {
            cache.get(i);
        }
        assertEquals(dp.getNumFetches(), valuesToAdd);
        assertEquals(cache.getNumMisses(), valuesToAdd);
    }
    /**
     * Tests adding a ton of values of only four different values into a small cache
     */
    @Test
    public void testInsertingSameValuesALot() {
        final NegativeIntegerLoader dp = new NegativeIntegerLoader();
        final Cache<Integer, Integer> cache = new LRUCache<>(dp, 4);
        final int valuesToAdd = 100000;
        for(int i=1; i<=valuesToAdd; i++) {
            cache.get(i%4 + 1);
        }
        assertEquals(dp.getNumFetches(), 4);
        assertEquals(cache.getNumMisses(), 4);
    }
    /**
     * Tests an edge case where the capacity is a large number (1 million)
     */
    @Test
    public void testHugeCache() {
        final NegativeIntegerLoader dp = new NegativeIntegerLoader();
        final int largeCapacity = 1000000;
        final Cache<Integer, Integer> cache = new LRUCache<>(dp, largeCapacity);
        for(int i=1; i<=largeCapacity; i++) {
            cache.get(i);
        }
        assertEquals(dp.getNumFetches(), largeCapacity);
        assertEquals(cache.getNumMisses(), largeCapacity);
    }
    /**
     * Tests the edge case for a cache of capacity 0
     */
    @Test
    public void testZeroCapacity() {
        final NegativeIntegerLoader dp = new NegativeIntegerLoader();
        final Cache<Integer, Integer> cache = new LRUCache<>(dp, 0);
        for(int i=1; i<=1000; i++) {
            cache.get(1);
        }
        assertEquals(dp.getNumFetches(), 1000);
        assertEquals(cache.getNumMisses(), 1000);
    }
    /**
     * Tests a simple case of a cache with capacity of one.
     */
    @Test
    public void capacityOneSimple() {
        final NegativeIntegerLoader dp = new NegativeIntegerLoader();
        final Cache<Integer, Integer> cache = new LRUCache<>(dp, 1);
        cache.get(1);
        cache.get(2);
        cache.get(1);
        assertEquals(dp.getNumFetches(), 3);
        assertEquals(cache.getNumMisses(), 3);
    }
    /**
     * Tests a simple case for a cache of capacity 2
     */
    @Test
    public void testTwoCapacitySimple() {
        final NegativeIntegerLoader dp = new NegativeIntegerLoader();
        final Cache<Integer, Integer> cache = new LRUCache<>(dp, 2);
        for(int i=1; i<=200; i++) {
            cache.get(i);
        }
        assertEquals(dp.getNumFetches(), 200);
        assertEquals(cache.getNumMisses(), 200);
    }
    /**
     * Tests a large case (many get's) for a cache of capacity 2
     * Complicates things by adding keys of 1, 2, 3 then 3, 2, 1 and repeats for 419 times.
     */
    @Test
    public void testTwoCapacityLarge() {
        final NegativeIntegerLoader dp = new NegativeIntegerLoader();
        final Cache<Integer, Integer> cache = new LRUCache<>(dp, 2);
        for(int i=1; i<=419; i++) {
            for(int j=1; j<=3; j++) {
                cache.get(j);
            }
            for(int j=3; j>=1; j--) {
                cache.get(j);
            }
        }
        //2 * n-1 + 4
        assertEquals(dp.getNumFetches(), 840);
        assertEquals(cache.getNumMisses(), 840);
    }
    /**
     * Tests a complex case for a cache of capacity 2
     * key 1 is first evicted, then key three is evicted, then key two is evicted, and finally key three gets evicted
     * so four evictions + two original values would make 6 fetches
     */
    @Test
    public void testCapacityTwoComplex() {
        final NegativeIntegerLoader dp = new NegativeIntegerLoader();
        final Cache<Integer, Integer> cache = new LRUCache<>(dp, 2);
        cache.get(1);
        cache.get(2);
        cache.get(2);
        cache.get(2);
        cache.get(3);
        cache.get(2);
        cache.get(2);
        cache.get(2);
        cache.get(1);
        cache.get(1);
        cache.get(3);
        cache.get(1);
        cache.get(2);
        assertEquals(dp.getNumFetches(), 6);
        assertEquals(cache.getNumMisses(), 6);
    }
    /**
     * Tests a complex case for a cache of capacity 3
     * nothing is evicted, but reordering does occur(which is prone to errors)
     */
    @Test
    public void testCapacityThreeComplex() {
        final NegativeIntegerLoader dp = new NegativeIntegerLoader();
        final Cache<Integer, Integer> cache = new LRUCache<>(dp, 3);
        cache.get(1);
        cache.get(2);
        cache.get(2);
        cache.get(2);
        cache.get(3);
        cache.get(2);
        cache.get(2);
        cache.get(2);
        cache.get(1);
        cache.get(1);
        cache.get(3);
        cache.get(1);
        cache.get(2);
        assertEquals(dp.getNumFetches(), 3);
        assertEquals(cache.getNumMisses(), 3);
    }
    /**
     * Tests an even more complex case for a cache of capacity 3
     * keys evicted: 1, 3, 2, 4
     */
    @Test
    public void testCapacityThreeMoreComplex() {
        final NegativeIntegerLoader dp = new NegativeIntegerLoader();
        final Cache<Integer, Integer> cache = new LRUCache<>(dp, 3);
        cache.get(1);
        cache.get(2);
        cache.get(2);
        cache.get(2);
        cache.get(3);
        cache.get(2);
        cache.get(2);
        cache.get(4);
        cache.get(1);
        cache.get(1);
        cache.get(3);
        cache.get(1);
        cache.get(2);
        assertEquals(dp.getNumFetches(), 7);
        assertEquals(cache.getNumMisses(), 7);
    }
    @Test
    /**
     * Tests a more complex case for a cache of capacity 4
     */
    public void testCapacityFourComplexTest() {
        final NegativeIntegerLoader dp = new NegativeIntegerLoader();
        final Cache<Integer, Integer> cache = new LRUCache<>(dp, 4);
        cache.get(1);
        cache.get(2);
        cache.get(2);
        cache.get(2);
        cache.get(3);
        cache.get(2);
        cache.get(2);
        cache.get(4);
        cache.get(5);
        cache.get(3);
        cache.get(5);
        cache.get(2);
        cache.get(1);
        cache.get(2);
        cache.get(2);
        cache.get(2);
        cache.get(1);
        cache.get(5);
        cache.get(3);
        cache.get(1);
        cache.get(3);
        cache.get(2);
        assertEquals(dp.getNumFetches(), 6);
        assertEquals(cache.getNumMisses(), 6);
    }

    @Test
    /**
     * Tests a more complex case for a cache of capacity 4
     */
    public void testCapacityFourComplexTest2() {
        final NegativeIntegerLoader dp = new NegativeIntegerLoader();
        final Cache<Integer, Integer> cache = new LRUCache<>(dp, 4);
        cache.get(1);
        cache.get(2);
        cache.get(2);
        cache.get(2);
        cache.get(3);
        cache.get(2);
        cache.get(2);
        cache.get(4);
        cache.get(5);
        cache.get(3);
        cache.get(5);
        cache.get(2);
        cache.get(1);
        cache.get(2);
        cache.get(2);
        cache.get(4);
        cache.get(1);
        cache.get(5);
        cache.get(3);
        cache.get(1);
        cache.get(3);
        cache.get(7);
        assertEquals(dp.getNumFetches(), 9);
        assertEquals(cache.getNumMisses(), 9);
    }
    /**
     * Tests another complex test of cache capacity four
     */
    @Test
    public void testCapacityFourComplexTest3() {
        final NegativeIntegerLoader dp = new NegativeIntegerLoader();
        final Cache<Integer, Integer> cache = new LRUCache<>(dp, 4);
        cache.get(10);
        cache.get(13);
        cache.get(12);
        cache.get(13);
        cache.get(12);
        cache.get(8);
        cache.get(3);
        cache.get(12);
        cache.get(10);
        cache.get(12);
        cache.get(10);
        assertEquals(dp.getNumFetches(), 6);
        assertEquals(cache.getNumMisses(), 6);
    }

    /**
     * yet another complex test of capacity size 4 for cache
     */
    @Test
    public void testCapacityFourComplexTest4() {
        final NegativeIntegerLoader dp = new NegativeIntegerLoader();
        final Cache<Integer, Integer> cache = new LRUCache<>(dp, 4);
        cache.get(10);
        cache.get(13);
        cache.get(12);
        cache.get(13);
        cache.get(12);
        cache.get(8);
        cache.get(3);
        cache.get(12);
        cache.get(10);
        cache.get(13);
        cache.get(8);
        cache.get(8);
        cache.get(21);
        cache.get(3);
        assertEquals(dp.getNumFetches(), 10);
        assertEquals(cache.getNumMisses(), 10);
    }
    /**
     * Tests a complex case for capacity equal to five
     */
    @Test
    public void testCapacityFiveVeryComplex() {
        final NegativeIntegerLoader dp = new NegativeIntegerLoader();
        final Cache<Integer, Integer> cache = new LRUCache<>(dp, 5);
        cache.get(10); //10
        cache.get(13); //10 13
        cache.get(2); // 10 13 2
        cache.get(3); //10 13 2 3
        cache.get(12); //10 13 2 3 12
        cache.get(10); //13 2 3 12 10
        cache.get(3); //13 2 12 10 3
        cache.get(13); //2 12 10 3 13
        cache.get(2); //12 10 3 13 2
        cache.get(10); // 12 3 13 2 10
        cache.get(13); // 12 3 2 10 13
        cache.get(30); // 3 2 10 13 30
        cache.get(8); // 2 10 13 30 8
        cache.get(8); // 2 10 13 30 8
        cache.get(3); // 10 13 30 8 3
        cache.get(12); // 13 30 8 3 12
        cache.get(10); // 30 8 3 12 10
        cache.get(193); // 8 3 12 10 193
        cache.get(8); // 3 12 10 193 8
        cache.get(8); // 3 12 10 193 8
        cache.get(21); // 12 10 193 8 21
        cache.get(3); // 10 193 8 21 3
        assertEquals(dp.getNumFetches(), 13);
        assertEquals(cache.getNumMisses(), 13);
    }
}