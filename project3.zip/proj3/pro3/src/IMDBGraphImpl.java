import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * implements the IMDBGraph interface. parses through the IMDB, producing a graph of movie and actor nodes
 */
public class IMDBGraphImpl implements  IMDBGraph {

    //these store the actors and movies in lists that are retrievable.
    private final Map<String, Node> actorList = new HashMap<>();
    private final Map<String, MovieNode> movieList = new HashMap<>();

    public IMDBGraphImpl (String actorsFilename, String actressesFilename) throws IOException {
        final Scanner actorScanner = new Scanner(new File(actorsFilename), "ISO-8859-1");
        parseDataBase(actorScanner);
        actorScanner.close();
        final Scanner actressScanner = new Scanner(new File(actressesFilename), "ISO-8859-1");
        parseDataBase(actressScanner);
        actressScanner.close();
    }
    /**
     * goes through all the text before we get to the actual list of actors/actresses and movies
     * @param scanner the scanner for either the actor or actress list file
     * @return the scanner, at the real starting line
     */
    private Scanner beginningOfFile(Scanner scanner) {
        String temp = "";
        //TEST:
        //scanner.next(Pattern.compile("THE ACTORS LIST")); //delete if this does not work
        while (!temp.contains("THE ACTORS LIST") && !temp.contains("THE ACTRESSES LIST") ) {
            temp = scanner.nextLine();
        }
        scanner.nextLine();
        scanner.nextLine();
        scanner.nextLine();
        scanner.nextLine(); //do this 4 times as the above is a more definitive point to end.
        return scanner;
    }
    /**
     * Parses the actor/actress files- creates movie and actor nodes, assigns neighbors, and puts them in a
     * hashset and hashmap
     * @param scanner the scanner for either the actor or actress list file
     */
    private void parseDataBase(Scanner scanner) {
        final String endLine = "SUBMITTING UPDATES";
        //above is what will be at the end of the file. so once it equals this line, we are done
        scanner = beginningOfFile(scanner);
        ActorNode actorNode = new ActorNode();
        String line = "";
        while (scanner.hasNextLine() && line != endLine) {
            line = scanner.nextLine();
            final String trimmedLine = line; //need this variable as, when checking if line is just whitespace,
            //need to trim it. and trimming the original line will make the first char not be a tab for movies: problem
            if (trimmedLine.trim().isEmpty()) { //we are at all whitespace. so afterwards, must be an actor.
                if (actorNode.getName() != null && actorNode.getNeighbors().size() > 0) { //if actor has valid movies as neighbors
                    actorList.put(actorNode.getName(), actorNode); //hashMap
                }
            } else if (line.charAt(0) != '\t' && line.indexOf("\t") != -1) { //second expression is error-checking
                final int firstTab = line.indexOf("\t");
                final String actorName = line.substring(0, firstTab); //since we know that first char is not tab, it
                //must be an actor.
                actorNode = new ActorNode(actorName);
                line = line.substring(firstTab).trim(); //remove the actor string, and trim it to have it start at movie
                final MovieNode movieNode = parseMovie(line);
                setNeighbors(movieNode, actorNode);
            } else {
                final MovieNode movieNode = parseMovie(line.trim());
                setNeighbors(movieNode, actorNode);
                //then we know it is a movie. and we add movie.
            }
        }
        //need below check because sometimes the file does not end w/ whitespace
        if (!actorList.containsKey(actorNode.getName())) {
            actorList.put(actorNode.getName(), actorNode);
        }
        System.out.println("ONE LIST DONE");
    }
    /**
     * adds neighbors to the movie and actor nodes.
     * @param movieNode the movie node
     * @param actorNode the actor node
     */
    private void setNeighbors(MovieNode movieNode, ActorNode actorNode) {
        //try-catch is if the movie is invalid, the movie is null so we do not add it as neighbor
        try {
            movieNode.addNeighbor(actorNode);
            actorNode.addNeighbor(movieNode);
        } catch (Exception e) {
            //null!
        }
    }
    /**
     * extracts the movie name, then, if a valid movie, produces a node/gets a node, and returns it
     * @param lineWithMovie the line from the scanner that supposedly has a movie in it
     * @return either a movie node with the title of the movie found in the scanner line,
     * or null if the movie name was not found/the movie name was invalid
     */
    private MovieNode parseMovie(String lineWithMovie) {
        final boolean isValid = isValidMovie(lineWithMovie);
        final String movieName = getMovieName(lineWithMovie);
        if (movieName != null && isValid) {
            if (movieList.containsKey(movieName)) {
                final MovieNode movieNode = movieList.get(movieName);
                return movieNode;
            } else {
                final MovieNode movieNode = new MovieNode(movieName);
                movieList.put(movieName, movieNode); //hashMap
                return movieNode;
            }
        }
        return null;
    }
    /**
     * obtains the movie name from the string via a regex pattern
     * @param line the string from the scanner where the movie name will be searched for
     * @return either the name of the movie if found, or null if a movie was not in the line
     */
    private String getMovieName(String line) {
        try {
            final Pattern p = Pattern.compile("(\\((\\d{4}|\\?{4})(\\/\\S+)*\\))");
            //the above pattern checks for all the possible data combinations. a date contains either
            // (NNNN), where N = number, (????), or (NNNN/II), where after / are roman numerals)
            final Matcher m = p.matcher(line);
            m.find();
            final int regexThing = m.start(); //finds first index of the pattern
            return line.substring(0, line.indexOf(")", regexThing)) + ")";
        } catch (IllegalStateException e) {
            return null; //this happens when the line is not a movie line. i.e. "---------" at the end!
        }
    }
    /**
     * checks if the movie is a valid movie. a valid movie's name does not start with quotations and does not contain (TV)
     * and does not contain (V)
     * @param movie the movie name that is being checked
     * @return false if the movie is invalid, true if valid
     */
    private boolean isValidMovie(String movie) {
        if(movie.charAt(0) == '\"' || movie.contains("(TV)") || movie.contains("(V)")) {
            return false;
        }
        return true;
    }
    /**
     * Gets all the actor nodes in the graph.
     * @return a collection of all the actor and actress nodes in the graph.
     */
    public Collection<? extends Node> getActors() {
        return actorList.values();
    }
    /**
     * Gets all the movie nodes in the graph.
     * @return a collection of all the movie nodes in the graph.
     */
    public Collection<? extends Node> getMovies() {
        return movieList.values();
    }
    /**
     * Returns the movie node having the specified name.
     * @param name the name of the requested movie
     * @return the movie node associated with the specified name or null
     * if no such movie exists.
     */
    public Node getMovie(String name) {
        return movieList.get(name);
    }
    /**
     * Returns the actor node having the specified name.
     * @param name the name of the requested actor
     * @return the actor node associated with the specified name or null
     * if no such actor exists.
     */
    public Node getActor(String name) {
        return actorList.get(name);
    }
}