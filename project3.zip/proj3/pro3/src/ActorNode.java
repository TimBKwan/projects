import java.util.ArrayList;
import java.util.Collection;

/**
 * implements the node class; for actors
 */
public class ActorNode implements Node {

    private String _name;
    private Collection<MovieNode> _listOfNeighbors;

    public ActorNode() {
        _listOfNeighbors = new ArrayList<>();
    }

    public ActorNode (String name) {
        _name = name;
        _listOfNeighbors = new ArrayList<>();
    }

    /**
     * adds a movie node to the neighbors of the actor
     * @param node the movie node to be added to the neighbor list
     */
    public void addNeighbor(MovieNode node) {
        _listOfNeighbors.add(node);
    }

    /**
     * gets the name of the actor node
     * @return the name of the actor
     */
    public String getName() {
        return _name;
    }

    /**
     * gets the list of movie node neighbors (movies that the actors was a part of)
     * @return the list of neighbors of the actor nodes (all movies)
     */
    public Collection<? extends Node> getNeighbors() {

        return _listOfNeighbors;
    }
}
