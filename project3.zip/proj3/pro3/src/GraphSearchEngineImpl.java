import java.util.*;
/**
 * the implementation of the graph search engine interface, which finds shortest path between two nodes
 */
public class GraphSearchEngineImpl implements GraphSearchEngine {
    /**
     * Finds a shortest path, if one exists, between nodes s and
     * t. The path will be a list: (s, ..., t). If no
     * path exists, then this method will return null.
     * @param s the start node.
     * @param t the target node.
     * @return a shortest path in the form of a List of Node objects
     * or null if no path exists.
     */
    public List<Node> findShortestPath(Node s, Node t) {
        //edge case: Node s == Node t
        if (s.equals(t)) {
            final List<Node> list = new ArrayList<>();
            list.add(t);
            return list;
        }
        final Collection<Node> visitedNodes = new HashSet<>();
        final Queue<Node> nodesToVisit = new LinkedList<>();
        final Map<Node, Integer> distances = new HashMap<Node, Integer>(); //distances per nodes
        nodesToVisit.add(s);
        distances.put(s, 0);
        while (nodesToVisit.size() > 0) {
            final Node n = nodesToVisit.remove();
            if (n != null && n.equals(t)) { //if true, the node was found
                return backTrack(distances, s, t);
            }
            visitedNodes.add(n);
            for(Node neighbor: n.getNeighbors()) {
                if (!visitedNodes.contains(neighbor) && !nodesToVisit.contains(neighbor)) {
                    nodesToVisit.add(neighbor);
                    distances.put(neighbor, 1+distances.get(n)); //distance is one farther than the parent (BFS)
                }
            }
        }
        return null; //means that it was not found
    }
    /**
     * Backtracks through the list after node t is found, keeping track of the nodes visited and returns the list of nodes
     * visited
     * @param distances the list of nodes and distances from the start node
     * @param s the start node
     * @param t the target node
     * @return the list of nodes for the shortest path from s to t in that order
     */
    private List<Node> backTrack(Map<Node, Integer> distances, Node s, Node t) {
        final List<Node> path = new ArrayList<>();
        Node cursor = t;
        path.add(cursor);
        Node minimumNode = t;
        while (!cursor.equals(s)) {
            int currentMin = Integer.MAX_VALUE;
            for (Node neighbor: cursor.getNeighbors()) { //goes through the neighbors of the current node in the path
                try {
                    final int currentDis = distances.get(neighbor);
                    if (currentDis < currentMin) {
                        currentMin = currentDis;
                        minimumNode = neighbor;
                    }
                } catch (Exception e) {
                    //try catch is needed as sometimes the node was never added to the distances HashMap.
                    //so it would produce null when trying to retrieve it
                }
            }
            cursor = minimumNode;
            path.add(cursor);
        }
        return reversePath(path);
    }
    /**
     * reverses the path, so that the first element of the list is the starting node.
     * @param path the path that was taken from t to s
     * @return the path that was taken starting from s to t
     */
    private List<Node> reversePath(List<Node> path) {
        final List<Node> newPath = new ArrayList<>();
        for (int i=path.size()-1; i>=0; i--) {
            newPath.add(path.get(i));
        }
        return newPath;
    }
}