import java.util.ArrayList;
import java.util.Collection;
/**
 * implements the node class; for movies
 */
public class MovieNode implements Node {
    private String _name;
    private Collection<ActorNode> _listOfNeighbors;

    public MovieNode (String name) {
        _name = name;
        _listOfNeighbors = new ArrayList<>();
    }

    /**
     * adds an actor neighbor to the list of neighbors
     * @param node the actor node that will be added
     */
    public void addNeighbor(ActorNode node) {
        _listOfNeighbors.add(node);
    }

    /**
     * gets the movie node
     * @return the name of the movie node
     */
    public String getName() {
        return _name;
    }

    /**
     * gets the list of actor neighbors (actors part of the movie)
     * @return the list of neighbors of the movie (all actors)
     */
    public Collection<? extends Node> getNeighbors() {
        return _listOfNeighbors;
    }


}
